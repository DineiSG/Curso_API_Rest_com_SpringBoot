package teste.Teste.Conexao.BD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteConexaoBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
