package teste.Teste.Conexao.BD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteConexaoBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteConexaoBdApplication.class, args);
	}

}
